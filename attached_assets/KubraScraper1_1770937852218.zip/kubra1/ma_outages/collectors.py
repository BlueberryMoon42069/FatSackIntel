import csv
import io
import requests
from datetime import datetime

from kubra import KubraScraper
from .config import (
    MA_UTILITIES, 
    MEMA_CSV_URL, 
    EVERSOURCE_REGIONS,
    EVERSOURCE_METADATA_URL,
    EVERSOURCE_DATA_URL_TEMPLATE
)


def collect_kubra_outages(utility_key):
    config = MA_UTILITIES.get(utility_key)
    if not config:
        raise ValueError(f"Unknown utility: {utility_key}")
    
    scraper = KubraScraper(
        config["instance_id"],
        config["view_id"],
        requests_per_minute=0,
    )
    
    outages = list(scraper.scrape())
    return outages


def get_eversource_directory():
    response = requests.get(EVERSOURCE_METADATA_URL, timeout=30)
    response.raise_for_status()
    return response.json()["directory"]


def collect_eversource_outages(region_key):
    config = EVERSOURCE_REGIONS.get(region_key)
    if not config:
        raise ValueError(f"Unknown Eversource region: {region_key}")
    
    directory = get_eversource_directory()
    url = EVERSOURCE_DATA_URL_TEMPLATE.format(
        directory=directory,
        region_id=config["region_id"]
    )
    
    response = requests.get(url, timeout=30)
    response.raise_for_status()
    data = response.json()
    
    records = []
    areas = data.get("file_data", {}).get("areas", [])
    
    def extract_towns(area_list, utility_name="Eversource"):
        for area in area_list:
            if "areas" in area:
                extract_towns(area["areas"], utility_name)
            else:
                cust_affected = area.get("cust_a", {}).get("val", 0)
                cust_served = area.get("cust_s", 0)
                percent_out = area.get("percent_out", 0.0)
                
                records.append({
                    "town": area.get("area_name", ""),
                    "utility": config["name"],
                    "customers_affected": cust_affected,
                    "customers_served": cust_served,
                    "percent_out": percent_out,
                })
    
    extract_towns(areas)
    return records


def collect_mema_data():
    response = requests.get(MEMA_CSV_URL, timeout=30)
    response.raise_for_status()
    
    reader = csv.DictReader(io.StringIO(response.text))
    records = list(reader)
    
    return records


def collect_all():
    results = {
        "collected_at": datetime.utcnow().isoformat(),
        "kubra": {},
        "eversource": {},
        "mema": None,
        "errors": []
    }
    
    for utility_key in MA_UTILITIES:
        try:
            outages = collect_kubra_outages(utility_key)
            results["kubra"][utility_key] = {
                "count": len(outages),
                "outages": outages
            }
        except Exception as e:
            results["errors"].append({
                "source": utility_key,
                "error": str(e)
            })
    
    for region_key in EVERSOURCE_REGIONS:
        try:
            outages = collect_eversource_outages(region_key)
            results["eversource"][region_key] = {
                "count": len(outages),
                "records": outages
            }
        except Exception as e:
            results["errors"].append({
                "source": region_key,
                "error": str(e)
            })
    
    try:
        mema_data = collect_mema_data()
        results["mema"] = {
            "count": len(mema_data),
            "records": mema_data
        }
    except Exception as e:
        results["errors"].append({
            "source": "mema",
            "error": str(e)
        })
    
    return results

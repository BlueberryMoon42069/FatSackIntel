import os
import psycopg2
from psycopg2.extras import execute_values
from datetime import datetime

DATABASE_URL = os.environ.get("DATABASE_URL")


def get_connection():
    return psycopg2.connect(DATABASE_URL)


def init_database():
    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                CREATE TABLE IF NOT EXISTS kubra_outages (
                    id SERIAL PRIMARY KEY,
                    collected_at TIMESTAMP NOT NULL DEFAULT NOW(),
                    utility VARCHAR(100) NOT NULL,
                    outage_id VARCHAR(100),
                    incident_id VARCHAR(100),
                    title VARCHAR(255),
                    customers_affected INTEGER,
                    crew_status VARCHAR(100),
                    etr TIMESTAMP,
                    cause TEXT,
                    start_time TIMESTAMP,
                    town VARCHAR(100),
                    longitude DOUBLE PRECISION,
                    latitude DOUBLE PRECISION,
                    geometry_type VARCHAR(20),
                    raw_data JSONB
                );
                
                CREATE INDEX IF NOT EXISTS idx_kubra_outages_collected_at 
                ON kubra_outages(collected_at);
                
                CREATE INDEX IF NOT EXISTS idx_kubra_outages_utility 
                ON kubra_outages(utility);
                
                CREATE INDEX IF NOT EXISTS idx_kubra_outages_town 
                ON kubra_outages(town);
                
                CREATE TABLE IF NOT EXISTS mema_outages (
                    id SERIAL PRIMARY KEY,
                    collected_at TIMESTAMP NOT NULL DEFAULT NOW(),
                    town VARCHAR(100) NOT NULL,
                    county VARCHAR(100),
                    mema_region VARCHAR(10),
                    utility VARCHAR(100),
                    total_customers INTEGER,
                    without_power INTEGER,
                    percent_without_power DOUBLE PRECISION,
                    notes TEXT,
                    last_updated TIMESTAMP
                );
                
                CREATE INDEX IF NOT EXISTS idx_mema_outages_collected_at 
                ON mema_outages(collected_at);
                
                CREATE INDEX IF NOT EXISTS idx_mema_outages_town 
                ON mema_outages(town);
                
                CREATE INDEX IF NOT EXISTS idx_mema_outages_utility 
                ON mema_outages(utility);
                
                CREATE TABLE IF NOT EXISTS eversource_outages (
                    id SERIAL PRIMARY KEY,
                    collected_at TIMESTAMP NOT NULL DEFAULT NOW(),
                    region VARCHAR(50) NOT NULL,
                    town VARCHAR(100) NOT NULL,
                    utility VARCHAR(100),
                    customers_affected INTEGER,
                    customers_served INTEGER,
                    percent_out DOUBLE PRECISION
                );
                
                CREATE INDEX IF NOT EXISTS idx_eversource_outages_collected_at 
                ON eversource_outages(collected_at);
                
                CREATE INDEX IF NOT EXISTS idx_eversource_outages_region 
                ON eversource_outages(region);
                
                CREATE INDEX IF NOT EXISTS idx_eversource_outages_town 
                ON eversource_outages(town);
            """)
        conn.commit()


def insert_kubra_outages(utility, outages, collected_at=None):
    if collected_at is None:
        collected_at = datetime.utcnow()
    
    records = []
    for outage in outages:
        desc = outage.get("desc", {})
        geom = outage.get("geom", {})
        
        cust_a = desc.get("cust_a", {})
        customers = cust_a.get("val") if isinstance(cust_a, dict) else None
        
        crew = desc.get("crew_status")
        crew_status = None
        if isinstance(crew, dict):
            crew_status = crew.get("EN-US") or crew.get("orig")
        
        cause = desc.get("cause")
        cause_str = None
        if isinstance(cause, dict):
            cause_str = cause.get("EN-US") or cause.get("orig")
        elif cause:
            cause_str = str(cause)
        
        etr = None
        if desc.get("etr"):
            try:
                etr = datetime.fromisoformat(desc["etr"].replace("Z", "+00:00"))
            except:
                pass
        
        start_time = None
        if desc.get("start_time"):
            try:
                start_time = datetime.fromisoformat(desc["start_time"].replace("Z", "+00:00"))
            except:
                pass
        
        lon, lat = None, None
        geom_type = None
        if geom.get("p"):
            import polyline
            coords = polyline.decode(geom["p"][0])[0]
            lat, lon = coords[0], coords[1]
            geom_type = "Point"
        elif geom.get("a"):
            geom_type = "Polygon"
            import polyline
            first_ring = geom["a"][0]
            coords = polyline.decode(first_ring)
            if coords:
                lat = sum(c[0] for c in coords) / len(coords)
                lon = sum(c[1] for c in coords) / len(coords)
        
        records.append((
            collected_at,
            utility,
            outage.get("id"),
            desc.get("inc_id"),
            outage.get("title"),
            customers,
            crew_status,
            etr,
            cause_str,
            start_time,
            desc.get("town"),
            lon,
            lat,
            geom_type,
            psycopg2.extras.Json(outage)
        ))
    
    if not records:
        return 0
    
    with get_connection() as conn:
        with conn.cursor() as cur:
            execute_values(
                cur,
                """INSERT INTO kubra_outages 
                   (collected_at, utility, outage_id, incident_id, title, 
                    customers_affected, crew_status, etr, cause, start_time,
                    town, longitude, latitude, geometry_type, raw_data)
                   VALUES %s""",
                records
            )
        conn.commit()
    
    return len(records)


def insert_mema_outages(records, collected_at=None):
    if collected_at is None:
        collected_at = datetime.utcnow()
    
    db_records = []
    for r in records:
        last_updated = None
        if r.get("Last Updated"):
            try:
                last_updated = datetime.strptime(r["Last Updated"], "%Y/%m/%d %I:%M %p")
            except:
                pass
        
        pct = r.get("Percent Without Power")
        if pct:
            try:
                pct = float(pct)
            except:
                pct = None
        
        db_records.append((
            collected_at,
            r.get("Town"),
            r.get("County"),
            r.get("MEMA Region"),
            r.get("Utility"),
            int(r.get("Total Customers", 0) or 0),
            int(r.get("Without Power", 0) or 0),
            pct,
            r.get("Notes"),
            last_updated
        ))
    
    if not db_records:
        return 0
    
    with get_connection() as conn:
        with conn.cursor() as cur:
            execute_values(
                cur,
                """INSERT INTO mema_outages 
                   (collected_at, town, county, mema_region, utility,
                    total_customers, without_power, percent_without_power,
                    notes, last_updated)
                   VALUES %s""",
                db_records
            )
        conn.commit()
    
    return len(db_records)


def insert_eversource_outages(region_key, records, collected_at=None):
    if collected_at is None:
        collected_at = datetime.utcnow()
    
    db_records = []
    for r in records:
        db_records.append((
            collected_at,
            region_key,
            r.get("town", ""),
            r.get("utility", ""),
            r.get("customers_affected", 0),
            r.get("customers_served", 0),
            r.get("percent_out", 0.0)
        ))
    
    if not db_records:
        return 0
    
    with get_connection() as conn:
        with conn.cursor() as cur:
            execute_values(
                cur,
                """INSERT INTO eversource_outages 
                   (collected_at, region, town, utility,
                    customers_affected, customers_served, percent_out)
                   VALUES %s""",
                db_records
            )
        conn.commit()
    
    return len(db_records)

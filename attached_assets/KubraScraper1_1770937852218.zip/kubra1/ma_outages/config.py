MA_UTILITIES = {
    "national_grid_ma": {
        "name": "National Grid Massachusetts",
        "instance_id": "9cb2e5b7-d321-4575-a552-4ae7078cbc31",
        "view_id": "ec79df5b-2c54-4fb9-a86a-b20775678236",
        "source": "kubra",
    },
}

EVERSOURCE_REGIONS = {
    "eversource_east_ma": {
        "name": "Eversource Eastern MA",
        "region_id": "east",
    },
    "eversource_west_ma": {
        "name": "Eversource Western MA", 
        "region_id": "west",
    },
}

EVERSOURCE_METADATA_URL = "https://outagemap.eversource.com/resources/data/external/interval_generation_data/metadata.json"
EVERSOURCE_DATA_URL_TEMPLATE = "https://outagemap.eversource.com/resources/data/external/interval_generation_data/{directory}/report_{region_id}.json"

MEMA_CSV_URL = "http://mema.mapsonline.net/power_outage_public.csv"

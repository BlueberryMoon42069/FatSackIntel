#!/usr/bin/env python3
import argparse
import json
import sys
from datetime import datetime

from ma_outages.collectors import (
    collect_kubra_outages, 
    collect_mema_data, 
    collect_eversource_outages,
    collect_all
)
from ma_outages.db import (
    init_database, 
    insert_kubra_outages, 
    insert_mema_outages,
    insert_eversource_outages
)
from ma_outages.config import MA_UTILITIES, EVERSOURCE_REGIONS


def cmd_init_db(args):
    print("Initializing database...")
    init_database()
    print("Database initialized successfully.")


def cmd_collect_kubra(args):
    utility = args.utility
    if utility not in MA_UTILITIES:
        print(f"Unknown utility: {utility}")
        print(f"Available: {', '.join(MA_UTILITIES.keys())}")
        sys.exit(1)
    
    print(f"Collecting outages from {MA_UTILITIES[utility]['name']}...")
    outages = collect_kubra_outages(utility)
    print(f"Found {len(outages)} outages")
    
    if args.store:
        count = insert_kubra_outages(utility, outages)
        print(f"Stored {count} records to database")
    
    if args.json:
        print(json.dumps(outages, indent=2, default=str))


def cmd_collect_eversource(args):
    region = args.region
    if region not in EVERSOURCE_REGIONS:
        print(f"Unknown region: {region}")
        print(f"Available: {', '.join(EVERSOURCE_REGIONS.keys())}")
        sys.exit(1)
    
    print(f"Collecting outages from {EVERSOURCE_REGIONS[region]['name']}...")
    records = collect_eversource_outages(region)
    print(f"Found {len(records)} town records")
    
    with_outages = [r for r in records if r.get("customers_affected", 0) > 0]
    if with_outages:
        print(f"  ({len(with_outages)} towns with active outages)")
    
    if args.store:
        count = insert_eversource_outages(region, records)
        print(f"Stored {count} records to database")
    
    if args.json:
        print(json.dumps(records, indent=2, default=str))


def cmd_collect_mema(args):
    print("Collecting MEMA data...")
    records = collect_mema_data()
    print(f"Found {len(records)} town records")
    
    if args.store:
        count = insert_mema_outages(records)
        print(f"Stored {count} records to database")
    
    if args.json:
        print(json.dumps(records, indent=2))


def cmd_collect_all(args):
    collected_at = datetime.utcnow()
    total_stored = 0
    
    for utility_key, config in MA_UTILITIES.items():
        print(f"Collecting from {config['name']}...")
        try:
            outages = collect_kubra_outages(utility_key)
            print(f"  Found {len(outages)} outages")
            if args.store:
                count = insert_kubra_outages(utility_key, outages, collected_at)
                total_stored += count
                print(f"  Stored {count} records")
        except Exception as e:
            print(f"  ERROR: {e}")
    
    for region_key, config in EVERSOURCE_REGIONS.items():
        print(f"Collecting from {config['name']}...")
        try:
            records = collect_eversource_outages(region_key)
            print(f"  Found {len(records)} town records")
            if args.store:
                count = insert_eversource_outages(region_key, records, collected_at)
                total_stored += count
                print(f"  Stored {count} records")
        except Exception as e:
            print(f"  ERROR: {e}")
    
    print("Collecting MEMA data...")
    try:
        records = collect_mema_data()
        print(f"  Found {len(records)} town records")
        if args.store:
            count = insert_mema_outages(records, collected_at)
            total_stored += count
            print(f"  Stored {count} records")
    except Exception as e:
        print(f"  ERROR: {e}")
    
    print(f"\nTotal records stored: {total_stored}")


def cmd_list_utilities(args):
    print("Available data sources:\n")
    
    print("Kubra (incident-level data):")
    for key, config in MA_UTILITIES.items():
        print(f"  {key}: {config['name']}")
    
    print("\nEversource (town-level data):")
    for key, config in EVERSOURCE_REGIONS.items():
        print(f"  {key}: {config['name']}")
    
    print("\nOther sources:")
    print("  mema: MEMA aggregated feed (all MA utilities)")


def main():
    parser = argparse.ArgumentParser(description="MA Power Outage Collector")
    subparsers = parser.add_subparsers(dest="command", help="Commands")
    
    init_parser = subparsers.add_parser("init-db", help="Initialize database tables")
    init_parser.set_defaults(func=cmd_init_db)
    
    kubra_parser = subparsers.add_parser("kubra", help="Collect Kubra outages")
    kubra_parser.add_argument("utility", help="Utility key (e.g., national_grid_ma)")
    kubra_parser.add_argument("--store", action="store_true", help="Store to database")
    kubra_parser.add_argument("--json", action="store_true", help="Output JSON")
    kubra_parser.set_defaults(func=cmd_collect_kubra)
    
    eversource_parser = subparsers.add_parser("eversource", help="Collect Eversource outages")
    eversource_parser.add_argument("region", help="Region key (e.g., eversource_east_ma)")
    eversource_parser.add_argument("--store", action="store_true", help="Store to database")
    eversource_parser.add_argument("--json", action="store_true", help="Output JSON")
    eversource_parser.set_defaults(func=cmd_collect_eversource)
    
    mema_parser = subparsers.add_parser("mema", help="Collect MEMA data")
    mema_parser.add_argument("--store", action="store_true", help="Store to database")
    mema_parser.add_argument("--json", action="store_true", help="Output JSON")
    mema_parser.set_defaults(func=cmd_collect_mema)
    
    all_parser = subparsers.add_parser("all", help="Collect from all sources")
    all_parser.add_argument("--store", action="store_true", help="Store to database")
    all_parser.set_defaults(func=cmd_collect_all)
    
    list_parser = subparsers.add_parser("list", help="List available utilities")
    list_parser.set_defaults(func=cmd_list_utilities)
    
    args = parser.parse_args()
    
    if args.command is None:
        parser.print_help()
        sys.exit(1)
    
    args.func(args)


if __name__ == "__main__":
    main()

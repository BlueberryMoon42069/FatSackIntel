# Massachusetts Power Outage Data Collector

## Overview
A Python tool for collecting and storing live power outage data from Massachusetts utilities. Supports National Grid (via Kubra API), Eversource Eastern/Western MA, and MEMA (Massachusetts Emergency Management Agency) aggregated data.

## Data Sources

### 1. National Grid MA (via Kubra API)
- **Instance ID**: `9cb2e5b7-d321-4575-a552-4ae7078cbc31`
- **View ID**: `ec79df5b-2c54-4fb9-a86a-b20775678236`
- **Data**: Individual outage locations with coordinates, customer counts, ETR, crew status
- **Update Frequency**: ~5 minutes

### 2. Eversource MA (via Direct API)
- **Eastern MA**: Towns like Boston, Cape Cod, South Shore (1.2M+ customers)
- **Western MA**: Towns like Springfield, Pittsfield, Amherst (215K customers)
- **Data**: Town-level customer counts and outage percentages
- **Update Frequency**: ~15 minutes

### 3. MEMA CSV Feed
- **URL**: `http://mema.mapsonline.net/power_outage_public.csv`
- **Data**: Town-level aggregated outages from all utilities (National Grid, Eversource Eastern/Western MA, Unitil)
- **Update Frequency**: ~15 minutes
- **Best for**: Historical tracking, statewide overview

## Usage

### Initialize Database
```bash
python collect.py init-db
```

### Collect from National Grid (Kubra)
```bash
python collect.py kubra national_grid_ma --store
python collect.py kubra national_grid_ma --json  # output JSON only
```

### Collect Eversource Data
```bash
python collect.py eversource eversource_east_ma --store
python collect.py eversource eversource_west_ma --store
python collect.py eversource eversource_east_ma --json  # output JSON only
```

### Collect MEMA Data
```bash
python collect.py mema --store
python collect.py mema --json  # output JSON only
```

### Collect from All Sources
```bash
python collect.py all --store
```

### List Available Utilities
```bash
python collect.py list
```

## Database Schema

### kubra_outages
- `collected_at` - When data was collected
- `utility` - Utility name (e.g., national_grid_ma)
- `outage_id` - Kubra outage identifier
- `incident_id` - Incident tracking ID
- `customers_affected` - Number of customers without power
- `crew_status` - Crew assignment status
- `etr` - Estimated time of restoration
- `cause` - Outage cause
- `start_time` - When outage started
- `town` - Town name
- `longitude`, `latitude` - Location coordinates
- `raw_data` - Full JSON from Kubra API

### eversource_outages
- `collected_at` - When data was collected
- `region` - Eversource region (eversource_east_ma or eversource_west_ma)
- `town` - Town name
- `utility` - Utility provider name
- `customers_affected` - Customers currently without power
- `customers_served` - Total customers in town
- `percent_out` - Percentage affected

### mema_outages
- `collected_at` - When data was collected
- `town` - Town name
- `county` - County name
- `mema_region` - MEMA region number
- `utility` - Utility provider
- `total_customers` - Total customers in town
- `without_power` - Customers without power
- `percent_without_power` - Percentage affected
- `last_updated` - When utility last updated

## Project Structure
```
kubra/            - Original Kubra scraper library
ma_outages/       - MA-specific collector
  config.py       - Utility instance/view IDs and API URLs
  collectors.py   - Data collection functions
  db.py           - Database operations
collect.py        - Main CLI tool
```

## Data Quality Notes

### MEMA CSV (Recommended for Historical Tracking)
- Standardized format with consistent fields
- Aggregated at town level - good for trends
- Covers all MA utilities in one source
- Easy to poll regularly (every 15 min)

### Kubra API (Recommended for Detailed Analysis)
- Individual outage locations with coordinates
- More granular data (incident-level)
- Includes crew status and ETR
- Currently only works for National Grid

### Eversource API (Town-Level Data)
- Direct from Eversource's outage map API
- Town-level aggregation (no individual incidents)
- Separate endpoints for Eastern MA and Western MA
- Good for tracking by town

## Recent Changes
- 2026-02-05: Added Eversource Eastern MA and Western MA collectors
- 2026-02-05: Added MA outage collector with database storage
- 2026-02-05: Fixed kubra scraper for multi-key datastatic structures
- 2026-02-05: Initial setup in Replit environment
